//함수 만드는 형식
//function 함수이름([인수,...])//자바스크립트는 함수호출시 인수개수 안 맞춰도 무방//오버로딩 안됨
//{함수가 실행되는 문장;//자바스크립트는 문장의 끝에 ";"를 안써도 무방
//        [return 값];
//}

//moveNext(이벤트 실행되는 객체, 최대 글자수, 포커스를 넘겨 줄 객체)
function moveNext(obj,len,nextobj){//자료형 제시 안해도 됨
	//value : 객체에 입력된 데이터를 의미. 값이 입력되면 true 아니면 false
	//length : 객체에 입력된 문자의 개수를 얻어온다
	if(obj.value.length == len){
		nextobj.focus();
	}	
}

//formCheck(검사할 데이터가 입력된 폼)
function formCheck(obj){
	//obj로 this(juminForm)이 넘어왔으므로 obj에는 document.juminForm이 저장
	
	//주민등록번호 앞자리에 데이터가 입력되었나 검사해서 입력되지 않았으면 false를 리턴
	if(!obj.jumin1.value || obj.jumin1.value.trim().length == 0){//아무것도 입력하지 않았는가? 또는 모두 공백이 입력되었는가?
			alert("주민등록번호 앞자리를 입력하세요");
	        obj.jumin1.value="";//다시 입력할때 기존에 입력한 데이터 지움
	        obj.jumin1.focus();//커서를 다시 되돌림
	        return false;
	}
	//주민등록번호 앞자리에 6글자가 입력되었나 검사해서 입력되지 않았으면 false를 리턴
	if(obj.jumin1.value.trim().length != 6){
		alert("주민등록번호 앞자리는 6글자를 입력해야합니다");
        obj.jumin1.value="";
        obj.jumin1.focus();
        return false;
	}
	//주민등록번호 앞자리는 0~9만 입력되었나 검사해서 입력되지 않았으면 false를 리턴
	//Number() => 자바의 parse,인수로 지정된 문자열을 숫자로 반환
	//isNaN()(not a number) => 인수로 지정된 데이터가 숫자가 아니면 true 숫자면 false
    if(isNaN(Number(obj.jumin1.value.trim()))){
    	alert("주민등록번호 앞자리는 0~9사이의 숫자만 입력해야 합니다");
        obj.jumin1.value="";
        obj.jumin1.focus();
        return false;
    }
	
  //주민등록번호 뒷자리에 데이터가 입력되었거나 검사해서 입력되지 않았으면 false를 리턴
	if(!obj.jumin2.value || obj.jumin2.value.trim().length == 0){//아무것도 입력되지 않았는가? 또는 전부 공백이 입력되었는가?
			alert("주민등록번호 뒷자리를 입력하세요");
			obj.jumin2.value="";//다시 입력할때 커서를 다시 되돌림(사용자 편의)
			obj.jumin2.focus();
			return false;
	}
	//주민등록번호 뒷자리에 7글자가 입력되었나 검사해서 입력되지 않았으면 false를 리턴
	if(obj.jumin2.value.trim().length != 7){
		alert("주민등록번호 뒷자리는 7글자를 입력해야 합니다");
		obj.jumin2.value="";//다시 입력할때 기존 입력한 데이터 지우고
		obj.jumin2.focus();//커서를 다시 되돌림(사용자 편의)
		return false;
	}
	//주민등록번호 뒷자리는 0~9만 입력되었나 검사해서 입력되지 않았으면 false를 리턴
	//Number() => 자바의 parse,인수로 지정된 문자열을 숫자로반환
	//isNaN()(not a number)=>인수로 지정된 데이터가 숫자가 아니면 true 숫자면 false
	if(isNaN(Number(obj.jumin2.value.trim()))){
		alert("주민등록번호 뒷자리는 0~9숫자만 입력해야 합니다");
		obj.jumin2.value="";//다시 입력할때 기존 입력한 데이터 지우고
		obj.jumin2.focus();//커서를 다시 되돌림(사용자 편의)
		return false;	
	}
	
	
	//여기까지 왔다는 것은 입력된 주민번호가 13자리 숫자가 입력되었다는 의미
	//이제 유효성 검사를 한다
	//유효성 검사를 하기 위해 주민등록번호를 하나의 문자열로 합친다
	jumin = obj.jumin1.value.trim() + obj.jumin2.value.trim();
	//jumin = Number(obj.jumin1.value.trim()) + Number(obj.jumin2.value.trim()); // 숫자 덧셈
	//javascript는 숫자로만 구성된 문자열을 사칙연산 할 경우 덧셈을 하는 경우만 문자열을 이어주고 덧셈을 제외한
	//나머지 연산은 지가 알아서 숫자로 변환시킨 후 연산한다.

    //가중치 2345678923456와 둘리주민번호 8304221185600의 각 자리를 곱해서 더하면 143
    var sum=0;//자바스크립트는 자료형 제시안함
    for(i=0;i<=12;i++){
    	//sum+=jumin.charAt(i)*(i<8?i+2:i-6);//가중치 규칙
    	sum += jumin.charAt(i)*(i%8+2);//가중치의 규칙
    }
    
    //가중치와 각 자리를 곱한 합계를 11로 나눈 나머지를 11에서 뺀 결과가 주민등록번호 마지막자리와 같아야 한다
    //연산결과가 10이상인 숫자는 10의 자리를 버린다
    result=(11-sum%11)%10;
    if(result != jumin.charAt(12)){
    	alert('주민등록번호가 올바르지 않습니다');
	    obj.jumin1.value="";
	    obj.jumin2.value="";
	    obj.jumin1.focus();
	    return false;
	 }
	//폼에 오류가 없이 여기까지 왔다는 것은 정상적으로 데이터가 입력된 경우이므로 true를 리턴
	return true;
}