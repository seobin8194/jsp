package com.myServlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/test01")
//서블릿
//jsp를 사용하기전에 사용했던 웹 개발 클래스
//서블릿 클래스는 HttpServlet 클래스를 상속받는다
public class test01 extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//body(content)의 타입(file/text)를 지칭
		response.setContentType("text/html; charset =UTF-8");
		//response : 클라이언트에게 응답할때, 클라이언트에게 보낼 html을 담는 객체
		PrintWriter out = response.getWriter();
		//사용자에게 보낼 html을 작성한다
		String param = request.getParameter("name");
		out.write("<!DOCTYPE html>");
		out.write("<html>");
		out.write("<head>");
		out.write("<meta charset = \"UTF-8\">");
		out.write("<title>나의 첫 서블릿</title>");
		out.write("</head>");
		out.write("<body>");
		out.write("나의 첫 서블릿");
		out.write(param + "님 환영합니다");
		out.write("</body>");
		out.write("</html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}

//서블릿의 생명주기
//1. 클라이언트(브라우저)가 해당 서블릿 호출
//2. [web server(정적처리, 단순히 요청에 응답) -> web container(동적 처리)] -> WAS(TOMCAT)
//3. web container가 해당 서블릿의 isLoad()호출 
//4. isLoad()가 false이면 서블릿클래스 로드 -> 서블릿 객체 생성 -> init()
//5. invoker() -> 새 스레드 실행(해당 클라이언트하고만 통신하는 스레드) -> service() -> doPost()나 doGet()
