package com.myServlet;

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/test02")
public class test02 extends HttpServlet {
	//init()
	//객체를 처음 생성해서 초기화할때 1번만 실행
	//설정정보, 자원 얻어오기, 페이지 이동 기능을 구현
	@Override
	public void init() throws ServletException {
		System.out.println("init() 메서드 실행");
	}

	//서블릿이 갱신되었을때, 서버가 restart하거나 shutdown을 실행할때 호출
	//해당 서블릿이 사용하고 있었던 자원을 반납
	@Override
	public void destroy() {
		System.out.println("destroy()실행");
	}

	//service()
	//클라이언트 요청이 있을때마다 호출
	//서블릿이 get방식으로 호출되면 doGet()메서드를 post방식으로 호출되면 doPost()를 호출
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().write("hello");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
