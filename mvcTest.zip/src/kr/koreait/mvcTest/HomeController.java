package kr.koreait.mvcTest;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//실행시 프로젝트 우클릭 -> run as -> run on server -> url에 파일명 입력

//브라우저 url창에 @WebServlet 어노테이션에서 지정한 요청이 들어 오면 @WebServlet 어노테이션이 붙어 있는 클래스(컨트롤러)에서
//get방식으로 요청이 들어 오면 doGet()메소드가 실행되고 post방식으로 요청이 들어 오면 doPost()메소드가 자동으로 실행된다

//@WebServlet 어노테이션에서 특정 페이지의 이름을 써주면 그 페이지 요청이 들어 왔을 때만 컨트롤러의 메소드가 실행되므로
//각각의 페이지마다 각각의 컨트롤러를 만들어야 하는 문제가 발생한다
//=> @WebServlet 어노테이션에서 와일드 카드 문자(*)를 사용하는 확장명 패턴의 요청을 받는다
//=> 확장명 패턴으로 요청을 받으면 파일명은 상관없이 동일한 확장명으로 요청되면 컨트롤러의 메소드가 실행된다
//=> 확정명 패턴 방식으로 요청을 받을때는 맨 앞에 "\"를 붙이지 않는다
//=> 확장명을 jsp가 아닌 다른 확장명으로 지정하면 어떤 페이지가 호출되었나 숨길 수 있다 -> 보안성이 향상
@WebServlet("*.nhn")
public class HomeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    public HomeController() {
        super();
    }

    //get 방식으로 요청이 들어 올때 자동으로 실행되는 메소드
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		actionDo(request, response);
	}

	//post 방식으로 요청이 들어 올때 자동으로 실행되는 메소드
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		actionDo(request, response);
	}
	
	//get 방식으로 요청이 들어오나 post 방식으로 요청이 들어오나 actionDo()메소드가 살행된다
	protected void actionDo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//한글 깨짐 방지
		request.setCharacterEncoding("UTF-8");
		
		//url 창에 입력된 요청을 받는다
		//getRequestURI() : url창에 요청된 경로와 페이지(context,요청)이름을 얻어 온다
		String url=request.getRequestURI();
		//System.out.println(url);
		//getContextPath() : url창에 요청된 경로만 얻어 온다
		String contextPath=request.getContextPath();
		//System.out.println(contextPath);
		//url창에 요청된 페이지 이름만 얻어 온다
		String context=url.substring(contextPath.length());
		//System.out.println(context);
		
		//요청에 따른 호출할 페이지의 경로와 이름을 지정한다
		//즉, 요청된 context에 따른 분기할 페이지를 결정한다
		String viewPage="/WEB-INF/";
		switch(context) {
		case "/index.nhn":
			viewPage+="hello.jsp";
			break;
		}
		
		//요청에 따른 호출할 페이지를 호출한다
		//RequestDispatcher인터페이스 객체를 이용해서 요청된 context에 따른 실제로 보여줄 페이지를 호출해 브라우저에 표시한다
		RequestDispatcher dispatcher=request.getRequestDispatcher(viewPage);//브라우저에 표시할 페이지 이름을 넣어 준디
		dispatcher.forward(request, response);//브라우저에 표시할 페이지를 호출한다
	}
}
