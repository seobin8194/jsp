package kr.koreait.onLinePoll;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class PollRead {
	//텍스트파일이 저장된 경로와 이름을 인수로 넘겨 받아 텍스트파일에 저장된 데이터를 읽어서 ArrayList에 저장한 후 리턴시키는 메서드
	public static ArrayList<String> pollRead(String filename){
		//텍스트파일에서 읽어 들인 데이터를 저장해 리턴시킬 ArrayList를 선언
		ArrayList<String> poll=null;
		//텍스트파일의 데이터를 읽어들일 Scanner선언
		Scanner scanner=null;
		
		//없는 파일을 가져왔을때 예외처리
		try {
			//텍스트파일에서 데이터를 읽어들일 Scanner객체 생성
			//파일을 읽을 때 반드시 파일객체 생성
			scanner=new Scanner(new File(filename));//파일 객체는 한번 쓰고 버림 -> 이름없는 객체
			//텍스트파일에서 데이터를 읽어들일 Scanner가 정상적으로 생성되었으므로 텍스트파일의 데이터를 읽어서 저장할 ArrayList객체 생성
			poll=new ArrayList<String>();
			
			//텍스트파일을 끝까지 반복하면서 투표데이터를 읽어들임
			while(scanner.hasNextLine()) {//hasNextLine() : Scanner에서 읽어들인 텍스트파일의 다음 줄이 있으면 TRUE, 없으면 FALSE
				String str=scanner.nextLine().trim();//trim():불필요한 공백 제거
				if(str.length()>0) {//텍스트파일의 빈칸을 인식하지 않기 위해
					poll.add(str);	
				}
			}
		}catch(FileNotFoundException e){
			System.out.println("파일이 존재하지 않습니다");	
		}finally {
			if(scanner != null) { scanner.close(); }
		}
		
//		for(String str:poll) {
//			System.out.println(str);
//		}
		
		//텍스트파일에서 읽어 들인 데이터가 저장된 ArrayList를 리턴
		return poll;
		
	}

}
