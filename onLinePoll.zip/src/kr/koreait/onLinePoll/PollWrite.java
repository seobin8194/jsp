package kr.koreait.onLinePoll;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class PollWrite {
	//투표결과를 저장할 텍스트파일의 경로와 이름,텍스트파일에 저장할 투표결과가 기억된 ArrayList를 인수로 받아
	//ArrayList에 저장된 데이터를 텍스트파일로 출력하는 메소드
	public static void pollWrite(String filename,ArrayList<String> poll) {
		//ArrayList에 저장된 데이터를 텍스트파일로 출력할때 사용할 PrintWriter선언
		PrintWriter printWriter=null;
		
		//없는 파일을 출력할때 예외처리
		try {
			//ArrayList에 저장된 데이터를 텍스트파일로 출력할 printWriter객체 생성
			//파일을 쓸때는 파일객체를 만들지 않아도 알아서 파일객체를 만든다
			printWriter=new PrintWriter(filename);
			
			//텍스트파일로 출력할 객체가 생성되었으면
			//ArrayList에 저장된 데이터의 개수만큼 반복하면서 ArrayList의 데이터를 텍스트파일로 출력
			for(String str:poll) {
				printWriter.write(str+"\r\n");
			}
		}catch(FileNotFoundException e) {
			System.out.println("파일이 존재하지 않습니다");
			
		}finally {
			//반드시 파일출력에 사용한 객체는 닫는다=>안닫으면 팡이로 출력한 데이터가 저장되지 않는다
			if(printWriter!=null) {
			printWriter.close();
			}
		}
	}
}
