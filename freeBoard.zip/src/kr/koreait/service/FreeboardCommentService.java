package kr.koreait.service;

import org.apache.ibatis.session.SqlSession;

import kr.koreait.dao.FreeboardCommentDAO;
import kr.koreait.mybatis.MySession;
import kr.koreait.vo.FreeboardCommentList;
import kr.koreait.vo.FreeboardCommentVO;

public class FreeboardCommentService {
	private static FreeboardCommentService instance=new FreeboardCommentService();
	private FreeboardCommentService() {}
	public static FreeboardCommentService getInstance(){
		return instance;
	}
	
	//list.jsp 에서 호출되어 메인 글의 글 번호를 넘겨 받고 mapper를 얻어 오고
	//댓글의 개수를 얻어 오는 DAO 클래스의 select sql 명령을 실행하는 메소드를 호출하는 메소드
	public int commentCount(int idx) {
		System.out.println("FreeboardCommentService 클래스의 commentCount() 메소드 실행");
		SqlSession mapper=MySession.getSession();
		int commentCount=FreeboardCommentDAO.getInstance().commentCount(mapper, idx);
		mapper.close();
		return commentCount;
	}
	
	//selectByIdx.jsp에서 호출되어 메인 글 번호를 넘겨 받고 mapper를 얻어 오고
	//DAO 클래스의 댓글 목록을 얻어 오는 select sql 명령을 실행하는 메소드를 호출하는 메소드
	public FreeboardCommentList selectCommentList(int idx) {
		System.out.println("FreeboardCommentService 클래스의 selectCommentList() 메소드 실행");
		SqlSession mapper=MySession.getSession();
		FreeboardCommentList freeboardCommentList=new FreeboardCommentList();
		freeboardCommentList.setFreeboardCommentList(FreeboardCommentDAO.getInstance().selectCommentList(mapper, idx));
		mapper.close();
		return freeboardCommentList;
	}
	
	//commentOK.jsp에서 댓글로 저장할 데이터가 저장된 객체를 넘겨 받고 mapper를 얻어 오고
	//DAO 클래스의 댓글을 저장하는 insert sql 며영을 실행하는 메소드를 호출하는 메소드
	public boolean insertComment(FreeboardCommentVO vo) {
		System.out.println("FreeboardCommentService 클래스의 insertComment() 메소드 실행");
		SqlSession mapper=MySession.getSession();
		try {
			FreeboardCommentDAO.getInstance().insertComment(mapper, vo);
			mapper.commit();
			mapper.close();
			return true;//댓글이 정상적으로 테이블에 저장되었으면 true를 리턴	
		}catch(Exception e) {
			mapper.close();
			return false;//댓글을 테이블에 저장하지 못하면 false를 리턴
		}
	}
	
	//commentOK.jsp에서 호출되어 삭제할 댓글이 저장된 객체를 넘겨 받고 mapper를 얻어 오고
	//댓글을 삭제하는 dao 클래스의 delete sql 명령을 실행하는 매소드를 호출하는 메소드
	public boolean deleteComment(FreeboardCommentVO vo) {
		System.out.println("FreeboardCommentService 클래스의 deleteComment() 메소드 실행");
		SqlSession mapper=MySession.getSession();
		//삭제하기 위해 입력한 비밀번호와 삭제할 댓글의 비밀번호를 비교하기 위해 삭제할 댓글 한 건을 얻어 온다
		FreeboardCommentVO original=FreeboardCommentDAO.getInstance().selectCommentByIdx(mapper, vo.getIdx());
		if(vo.getPassword().trim().equals(original.getPassword().trim())){
			FreeboardCommentDAO.getInstance().deleteComment(mapper, vo.getIdx());
			mapper.commit();
			mapper.close();
			return true;	
		}else {
			mapper.close();
			return false;
		}	
	}
	
	//commentOK.jsp에서 호출되어 수정할 댓글이 저장된 객체를 넘겨 받고 mapper를 얻어 오고
	//댓글을 수정하는 DAO 클래스의 update sql 명령을 실행하는 메소드를 호출하는 메소드
	public boolean updateComment(FreeboardCommentVO vo) {
		System.out.println("FreeboardCommentService 클래스의 updateComment() 메소드 실행");
		SqlSession mapper=MySession.getSession();
		//수정하기 위해 입력한 비밀번호와 수정할 댓글의 비밀번호를 비교하기 위해 수정할 댓글 한 건을 얻어 온다
		FreeboardCommentVO original=FreeboardCommentDAO.getInstance().selectCommentByIdx(mapper, vo.getIdx());
		if(vo.getPassword().trim().equals(original.getPassword().trim())) {
			FreeboardCommentDAO.getInstance().updateComment(mapper, vo);
			mapper.commit();
			mapper.close();
			return true;
		}else {
			mapper.close();
			return false;
		}
		
	}
}
