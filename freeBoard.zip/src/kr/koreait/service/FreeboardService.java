package kr.koreait.service;

import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;

import kr.koreait.dao.FreeboardDAO;
import kr.koreait.mybatis.MySession;
import kr.koreait.vo.FreeboardList;
import kr.koreait.vo.FreeboardVO;

public class FreeboardService {
	private static FreeboardService instance=new FreeboardService();
	private FreeboardService() {}
	public static FreeboardService getInstance() {
		return instance;
	}
	
	//insertOK.jsp에서 테이블에 저장할 메인 글이 저장된 객체를 넘겨 받고 mapper를 얻어 오고
	//메인 글을 저장하는 DAO 클래스의 insert sql 명령을 실행하는 메소드를 호출하는 메소드
	public void insert(FreeboardVO vo) {
		System.out.println("FreeboardService 클래스의 insert() 메소드 실행");
		SqlSession mapper=MySession.getSession();
		FreeboardDAO.getInstance().insert(mapper, vo);
		mapper.commit();
		mapper.close();
	}
	
	//list.jsp에서 브라우저에 표시할 페이지 번호를 넘겨 받고 mapper를 얻어 오고
	//메인 글 한 페이지 분량을 얻어 오는 DAO 클래스의 select sql 명령을 실행하는 메소드를 호출하는 메소드
	public FreeboardList selectList(int currentPage) {
		System.out.println("FreeboardService 클래스의 selectList() 메소드 실행");
		SqlSession mapper=MySession.getSession();
		int pageSize=10;
		int totalCount=FreeboardDAO.getInstance().selectCount(mapper);
		FreeboardList freeboardList=new FreeboardList(pageSize, totalCount, currentPage);
		HashMap<String, Integer> hmap=new HashMap<String,Integer>();
		hmap.put("startNo", freeboardList.getStartNo());
		hmap.put("endNo", freeboardList.getEndNo());
		freeboardList.setFreeboardList(FreeboardDAO.getInstance().selectList(mapper, hmap));
		mapper.close();
		return freeboardList;	
	}
	
	//increment.jsp에서 조회수를 증가시킬 글 번호를 넘겨 받고 mapper를 얻어 오고
	//메인 글의 조회수를 증가시키는 DAO 클래스의 update sql 명령을 실행하는 메소드를 호출하는 메소드
	public void increment(int idx) {
		System.out.println("FreeboardService 클래스의 increment() 메소드 실행");
		SqlSession mapper=MySession.getSession();
		FreeboardDAO.getInstance().increment(mapper, idx);
		mapper.commit();
		mapper.close();
	}
	
	//selectByIdx.jsp 에서 메인 글의 글 번호를 넘겨 받고 mapper를 얻어 오고
	//메인 글 한 건을 얻어 오는 DAO 클래스의 select sql 명령을 실행하는 메소드를 호출하는 메소드
	public FreeboardVO selectByIdx(int idx) {
		System.out.println("FreeboardService 클래스의 selectByIdx() 메소드 실행");
		SqlSession mapper=MySession.getSession();
		FreeboardVO vo=FreeboardDAO.getInstance().selectByIdx(mapper, idx);
		mapper.close();
		return vo;
	}
	
	//updateOK.jsp에서 수정할 메인 글이 저장된 객체를 넘겨 받고 mapper를 얻어 오고
	//메인 글 한 건을 수정하는 DAO 클래스의 update sql 명령을 실행하는 메소드를 호출하는 매소드
	public void update(FreeboardVO vo) {
		System.out.println("FreeboardService 클래스의 update() 메소드 실행");
		SqlSession mapper=MySession.getSession();
		FreeboardDAO.getInstance().update(vo, mapper);
		mapper.commit();
		mapper.close();	
	}
	
	//deleteOK.jsp에서 호출되어 삭제할 메인 글 번호를 넘겨 받고 mapper를 얻어 오고
	//메인 글 한 건을 삭제하는 DAO 클래스의 delete sql 명령을 실행하는 메소드를 호출하는 메소드
	public void delete(int idx) {
		System.out.println("FreeboardService 클래스의 delete() 메소드 실행");
		SqlSession mapper=MySession.getSession();
		FreeboardService.getInstance().delete(idx);
		mapper.commit();
		mapper.close();
		
	}

}
