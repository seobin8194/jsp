package kr.koreait.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;

import kr.koreait.dao.CategoryDAO;
import kr.koreait.mybatis.MySession;
import kr.koreait.vo.CategoryList;
import kr.koreait.vo.CategoryVO;

public class CategoryService {
	private static CategoryService instance=new CategoryService();
	private CategoryService() {}
	public static CategoryService getInstance() {return instance;}

	//insert.jsp에서 호출되어 테이블에 저장할 메인 카테고리가 저장된 객체를 넘겨 받고 mapper를 얻어 오고
	//CategoryDAO 클래스의 메인 카테고리를 저장하는 insert sql 명령을 실행하는 메소드를 호출하는 메소드
	public void insert(CategoryVO vo) {
		System.out.println("CaterotyService 클래스의 insert() 메소드 실행");
		//mybatis mapper를 얻어 온다
		SqlSession mapper=MySession.getSession();
		
		CategoryDAO.getInstance().insert(mapper, vo);
		//데이터베이스의 테이블의 내용을 변경시키는 sql 명령인 insert delete update 명령을 실행하고 난 후 
		//반드시 작업결과를 반영시키기 위해 commit()메소드를 실행해야한다
		mapper.commit();
		//mapper가 open되서 넘어온다 => 메소드가 종료되기 전에 close시켜야 한다
		mapper.close();
	}
	
	//reply.jsp에서 호출되어 테이블에 저장할 서브 카테고리와 저장할 서브 카테고리의 부모 카테고리 정보가 저장된 객체를 넘겨 받고
	//mapper를 얻어 오고 sql 실행전 전처리를 하고 CategoryDAO 클래스의 서브 카테고리를 저장하는 insert sql명령을 실행하는 매소드를 호출하는 메소드
	public void reply(CategoryVO vo) {
		System.out.println("CaterotyService 클래스의 reply() 메소드 실행");
		SqlSession mapper=MySession.getSession();
		
		//서브 카테고리의 위치를 결정하기 위해 lev와 seq를 1씩 증가시킨다
		vo.setLev(vo.getLev()+1);//서브카테고리의 레벨을 부모 카테고리보다 1증가 시킨다
		vo.setSeq(vo.getSeq()+1);//서브 카테고리가 부모 카테고리 바로 아래 나와야 하므로 출력순서를 1증가 시킨다
		
		//서브 카테고리를 위치에 맞게 삽입하기 위해 같은 카테고리 그룹(ref)의 카테고리 출력순서(seq)를 조정한다
		//새로 삽입된 서브 카테고리가 부모 카테고리 바로 아래에 나오고 나머지는 다 1씩 밀린다
		HashMap<String, Integer> hmap=new HashMap<>();
		hmap.put("ref", vo.getRef());
		hmap.put("seq", vo.getSeq());
		//카테고리의 출력순서를 조장하는 메소드를 실행
		CategoryDAO.getInstance().increment(mapper, hmap);
		
		//서브카테고리를 삽입하는 메소드를 실행
		CategoryDAO.getInstance().reply(mapper, vo);
	
		mapper.commit();
		mapper.close();
	}
	
	//list.jsp에서 호출되어 mapper를 얻어 오고 CategoryDAO 클래스의 테이블에 저장된 전체 카테고리 목록을 
	//얻어 오는 select sql 명령을 실행하는 메소드를 호출하는 메소드
	public CategoryList selectList() {
		System.out.println("CaterotyService 클래스의 selectList() 메소드 실행");
		SqlSession mapper=MySession.getSession();
		
		//카테고리 목록을 저장할 객체를 선언
		CategoryList categoryList=new CategoryList();
		
		//테이블에서 얻어온 카테고리 목록을 CategoryList 클래스의 ArrayList에 저장
		categoryList.setCategoryList(CategoryDAO.getInstance().selectList(mapper));
		
		mapper.close();
		
		//카테고리 목록을 리턴
		return categoryList;		
	}
	
	//delete.jsp에서 호출되어 식제할 카테코리 정보가 저장된 객체를 넘겨 받고 mapper를 얻어 오고
	//CategoryDAO 클래스의 테이블에 저장된 삭제할 카테고리 목록을 얻어 오는 select sql 명령을 실행하는 메소드를 호출하는 메소드
	public ArrayList<CategoryVO> deleteList(CategoryVO vo){
		System.out.println("CategoryService 클래스의 deleteList() 메소드 실행");
		SqlSession mapper=MySession.getSession();
		ArrayList<CategoryVO> deleteList=CategoryDAO.getInstance().deleteList(mapper, vo);
		mapper.close();
		return deleteList;
	}
	
	//delete.jsp와 update.jsp에서 호출되어 카테고리 번호를 넘겨 받고 mapper를 얻어 온 후
	//CategoryDAO 클래스의 테이블에 저장된 카테고리 1건을 얻어 오는 select sql을 실행하는 메소드를 호출하는 메소드
	public CategoryVO selectByIdx(int idx) {
		System.out.println("CaterotyService 클래스의 selectByIdx() 메소드 실행");
		SqlSession mapper=MySession.getSession();
		CategoryVO vo=CategoryDAO.getInstance().selectByIdx(mapper, idx);
		mapper.close();
		return vo;
	}
	
	//update.jsp에서 호출되어 수정할 카테고리 정보가 저장된 객체를 넘겨 받고 mapper를 얻어 오고
	//CategoryDAO 클래스의 테이블에서 카테고리 한 건을 수정하는 update sql을 실행하는 메소드를 호출하는 메소드
	public void update(CategoryVO vo) {
		System.out.println("CaterotyService 클래스의 update() 메소드 실행");
		SqlSession mapper=MySession.getSession();
		CategoryDAO.getInstance().update(mapper, vo);
		mapper.commit();
		mapper.close();
	}
	
	//delete.jsp에소 호출되어 삭제할 카테고리 번호를 넘겨 받고 mapper를 얻어 오고
	//CategoryDAO 클래스의 카테고리 한 건을 삭제하는 delete sql을 실행하는 메소드를 호출하는 매소드
	public void delete(int idx) {
		System.out.println("CaterotyService 클래스의 delete() 메소드 실행");
		SqlSession mapper=MySession.getSession();
		 CategoryDAO.getInstance().delete(mapper, idx);
		mapper.commit();
		mapper.close();
	}
	
	//delete.jsp에서 호출되어 삭제할 카테고리 번호를 넘겨 받고 mapper를 얻어 오고
	//CategoryDAO 클래스의 테이블에 저장된 카테고리 한 건을 "삭제된 카테고리 입니다"로 수정하는 update sql 명령을 실행하는 메소드를 호출하는 메소드
	public void deleteCategory(int idx) {
		System.out.println("CategoryService 클래스의 deleteCategory() 메소드 실행");
		SqlSession mapper=MySession.getSession();
		CategoryDAO.getInstance().deleteCategory(mapper, idx);
		mapper.commit();
		mapper.close();
	}
	
	//delete.jsp에서 호출되어 삭제할 카테고리 번호를 넘겨 받고 mapper를 얻어 온 후
	//CategoryDAO 클래스의 테이블에 저징된 카테고리의 deleteCheck 필드를 "yes"로 수정하는 update sql 명령을 실행하는 메소드를 호출하는 메소드
	public void deleteCheck(int idx) {
		System.out.println("CategoryService 클래스의 deleteCheck() 메소드 실행");
		SqlSession mapper=MySession.getSession();
		CategoryDAO.getInstance().deleteCheck(mapper, idx);
		mapper.commit();
		mapper.close();	
	}
	
	//delete.jsp에서 호출되어 seq를 다시 부여할 카테고리 그룹을 넘겨 받고 mapper를 얻어 오고
	//CategoryDAO 클래스의 테이블에 저장된 삭제한 카테고리 그룹의 seq를 0부터 다시 부여하는 update sql 명령을 실행하는 메소드를 호출하는 메소드
	public void reSeq(int ref) {
		System.out.println("CategoryService 클래스의 reSeq() 메소드 실행");
		SqlSession mapper=MySession.getSession();
		//seq를 다시 부여할 카테고리 그룹만 얻어 와서 ArrayList에 저장한다
		ArrayList<CategoryVO> refList=CategoryDAO.getInstance().selectRef(mapper, ref);
		//ArrayList로 얻어 온 카테고리 그룹의 개수만큼 반복하면서 seq를 0부터 다시 부여한다
		for(int i=0;i<refList.size();i++) {
			//seq 를 수정할 카테고리 일련번호(idx)와 seq를 수정할 데이터(i)를 HashMap 객체에 저장한다
			HashMap< String, Integer> hmap=new HashMap<>();
			hmap.put("idx", refList.get(i).getIdx());
			hmap.put("seq", i);
			//seq를 수정하는 메소드를 호출한다
			CategoryDAO.getInstance().updateSeq(mapper, hmap);
		}
		mapper.commit();
		mapper.close();
		
	}
	
	//delete.jsp에서 호출되어 복구할 카테고리 번호를 넘겨 받고 mapper를 얻어 오고
	//CategoryDAO 클래스의 테이블에 저장된 카테고리의 deleteCheck 필드를 "no"로 변경하는 update sql 명령을 실행하는 메소드를 호출하는 메소드
	public void deleteRestore(int idx) {
		System.out.println("CategoryService 클래스의 deleteRestore() 메소드 실행");
		SqlSession mapper=MySession.getSession();
		CategoryDAO.getInstance().deleteRestore(mapper, idx);
		mapper.commit();
		mapper.close();
		
	}
	
	//deleteReport.jsp에서 호출되어 신고할 카테고리 번호를 넘겨 받고 mapper를 얻어 오고
	//CategoryDAO 클래스의 테이블에 저장된 카테고리의 deleteReport 필드를 1증가 시키는 update sql 명령을 실행하는 메소드를 호츨하는 메소드
	public void deleteReport(int idx) {
		System.out.println("CategoryService 클래스의 deleteReport() 메소드 실행");
		SqlSession mapper=MySession.getSession();
		CategoryDAO.getInstance().deleteReport(mapper, idx);
		mapper.commit();
		mapper.close();	
	}
}
