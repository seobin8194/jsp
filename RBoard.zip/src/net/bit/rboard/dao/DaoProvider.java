package net.bit.rboard.dao;

public class DaoProvider {
	private static DaoProvider instance = new DaoProvider();
	private DaoProvider() {}
	public static DaoProvider getInstance() {return instance;}
	
	RBoardDao dao = new RBoardDao();
	RBoardCommentDao commentDao = new RBoardCommentDao();
	
	public RBoardDao getDao() {
		return dao;
	}
	public RBoardCommentDao getCommentDao() {
		return commentDao;
	}
}
