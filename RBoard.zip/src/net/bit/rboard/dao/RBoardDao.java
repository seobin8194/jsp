package net.bit.rboard.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import net.bit.rboard.db.DBUtil;
import net.bit.rboard.vo.RBoardVO;

public class RBoardDao {
	//전체 개수를 구하는 메소드
	public int selectCount(Connection conn) {
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.createStatement();
			String sql = "select count(*) from rboard";
			rs = stmt.executeQuery(sql);
			rs.next();
			return rs.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(rs);
		}
		return 0;
	}
	
	//레코드를 추가하는 메소드
	public int insert(Connection conn, RBoardVO vo) {
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement("insert into rboard"
					+ "(idx, ref, lev, seq, name, password, title, content, wdate, hit, ip)"
					+ "values (rboard_idx_seq.NEXTVAL, rboard_idx_seq.CURRVAL, 0, 0, ?, ?, ?, ?, ?, 0, ?)");
			pstmt.setString(1, vo.getName());
			pstmt.setString(2, vo.getPassword());
			pstmt.setString(3, vo.getTitle());
			pstmt.setString(4, vo.getContent());
			pstmt.setString(5, vo.getWdate());
			pstmt.setString(6, vo.getIp());
			return pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
		}
		return 0;	
	}
	
	//해당 페이지 목록을 리턴하는 메소드
	public List<RBoardVO> select(Connection conn, int startNo, int endNo){
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		 try {
			 //startNo부터 endNo에 해당하는 글의 모든 정보를 가져온다
			 //lev 역순 lev내에서는 seq순으로 가져온다
			pstmt = conn.prepareStatement(
						"select idx, ref, lev, seq, name, password, title, content, wdate, hit, ip from ( "
					  + "    select rownum rnum, idx, ref, lev, seq, name, password, title, content, wdate, hit, ip from ( "
					  + "        select * from rboard m order by ref desc, lev, seq"
					  + "    ) where rownum <= ? "
					  + ") where rnum >= ?");
			pstmt.setInt(1, endNo);
			pstmt.setInt(2, startNo);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				List<RBoardVO> list = new ArrayList<RBoardVO>();
				do {
					//테이블에서 가져온 각 글의 정보들을 vo형태로 변경하여 list에 추가한다
					list.add(makeVo(rs));
				} while(rs.next());
				return list;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(rs);
		}
		 return Collections.emptyList();	
	}
	
	//select()에서 가져온 글 한건을 vo 객체에 대입하는 메소드
	protected RBoardVO makeVo(ResultSet rs) {
		RBoardVO vo = new RBoardVO();
		try {
			vo.setIdx(rs.getInt("idx"));
			vo.setRef(rs.getInt("ref"));
			vo.setLev(rs.getInt("lev"));
			vo.setSeq(rs.getInt("seq"));
			vo.setName(rs.getString("name"));
			vo.setPassword(rs.getString("password"));
			vo.setTitle(rs.getString("title"));
			vo.setContent(rs.getString("content"));
			vo.setWdate(rs.getString("wdate"));
			vo.setHit(rs.getInt("hit"));
			vo.setIp(rs.getString("ip"));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return vo;	
	}
	
	//조회수를 증가시키는 메소드
	public void increment(Connection conn, int idx) {
		System.out.print("increment dao 실행");
		PreparedStatement pstmt = null;
		try {
			String sql ="update rboard set hit = hit + 1 where idx = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, idx);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
		}	
	}
	
	//글 한건을 얻어 오는 메소드
	public RBoardVO selectByIdx(Connection conn, int idx) {
		System.out.print("selectByIdx dao 실행" + idx);
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			String sql = "select * from rboard where idx = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, idx);
			rs = pstmt.executeQuery();
			//얻어 온 글 한건을 vo 형태로 변경하여 리턴한다
			if(rs.next()) {return makeVo(rs);}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(rs);
		}
		return null;	
	}
	
	//seq조절하는 메소드
	//크거나 같은 seq 모두 1씩 증가시킨다
	public int incrementSeq(Connection conn, int ref, int seq) {
		PreparedStatement pstmt = null;
		try {
			String sql = "update rboard set seq = seq + 1 where ref = ? and seq >= ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, ref);
			pstmt.setInt(2, seq);
			return pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.close(pstmt);
		}
		return 0;	
	}
	
	//답글을 다는 메소드
	public int reply(Connection conn, RBoardVO vo) {
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement("insert into rboard"
					+ "(idx, ref, lev, seq, name, password, title, content, wdate, hit, ip)"
					+ "values (rboard_idx_seq.NEXTVAL, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)");
			pstmt.setInt(1, vo.getRef());
			pstmt.setInt(2, vo.getLev());
			pstmt.setInt(3, vo.getSeq());
			pstmt.setString(4, vo.getName());
			pstmt.setString(5, vo.getPassword());
			pstmt.setString(6, vo.getTitle());
			pstmt.setString(7, vo.getContent());
			pstmt.setString(8, vo.getWdate());
			pstmt.setString(9, vo.getIp());
			return pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
		}
		return 0;		
	}
	
	//수정 메소드
	public int update(Connection conn, RBoardVO vo) {
		PreparedStatement pstmt = null;
		try {
			String sql = "update rboard set title=?, content=? where idx=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getTitle());
			pstmt.setString(2, vo.getContent());
			pstmt.setInt(3, vo.getIdx());
			return pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
		}
		
		return 0;	
	}
	
	//삭제 메소드
	public int delete(Connection conn, int idx) {
		PreparedStatement pstmt = null;
		try {
			String sql = "delete from rboard where idx = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, idx);
			return pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
		}
		return 0;	
	}

}
