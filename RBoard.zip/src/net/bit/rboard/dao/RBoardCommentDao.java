package net.bit.rboard.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import net.bit.rboard.db.DBUtil;
import net.bit.rboard.vo.RBoardCommentVO;

public class RBoardCommentDao {
	//댓글 한건을 추가하는 메소드
	public int insert(Connection conn, RBoardCommentVO vo) {
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(
					"insert into rboard_comment(idx, ref, name, password, content, wdate, ip) "
				  + "values(rboard_comment_idx_seq.NEXTVAL, ?, ?, ?, ?, ?, ?)");
			pstmt.setInt(1, vo.getRef());
			pstmt.setString(2,vo.getName() );
			pstmt.setString(3,vo.getPassword() );
			pstmt.setString(4,vo.getContent() );
			pstmt.setString(5,vo.getWdate() );
			pstmt.setString(6,vo.getIp());
			return pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
		}
		return 0;
	}
	
	//원본글에 대한 댓글의 개수를 구하는 메소드
	public int selectCount(Connection conn, int ref) {
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.createStatement();
			String sql = "select count(*) from rboard_comment where ref =" + ref;
			rs = stmt.executeQuery(sql);
			rs.next();
			return rs.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(stmt);
		}
		return 0;
	}
	
	//댓글목록을 구하는 메소드
	public List<RBoardCommentVO> select(Connection conn, int ref){
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement("select * from rboard_comment where ref = ?");
			pstmt.setInt(1, ref);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				List<RBoardCommentVO> list = new ArrayList<RBoardCommentVO>();
				do {
					list.add(makeVo(rs));
				}while(rs.next());
				return list;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(rs);
		}
		return Collections.emptyList();	
	}
	
	//댓글 한건을 vo로 만드는 메소드
	protected RBoardCommentVO makeVo(ResultSet rs) {
		RBoardCommentVO vo = new RBoardCommentVO();
		try {
			vo.setIdx(rs.getInt("idx"));
			vo.setRef(rs.getInt("ref"));
			vo.setName(rs.getString("name"));
			vo.setPassword(rs.getString("password"));
			vo.setContent(rs.getString("content"));
			vo.setWdate(rs.getString("wdate"));
			vo.setIp(rs.getString("ip"));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return vo;	
	}

}
