package net.bit.rboard.service;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;

import net.bit.rboard.dao.DaoProvider;
import net.bit.rboard.dao.RBoardDao;
import net.bit.rboard.db.DBCPProvider;
import net.bit.rboard.db.DBUtil;
import net.bit.rboard.vo.RBoardVO;

public class UpdateService {
	private static UpdateService instance = new UpdateService();
	private UpdateService() {}
	public static UpdateService getInstance() {return instance;}
	
	public int update(RBoardVO vo) {
		Connection conn = null;
		
		try {
			conn = DBCPProvider.getConnection();
			RBoardDao dao = DaoProvider.getInstance().getDao();
			//입력한 비밀번호가 올바른지 확인위해 본래 비말번호를 얻는디
			RBoardVO originVo = dao.selectByIdx(conn, vo.getIdx());
			if(originVo.getPassword().equals(vo.getPassword())) {
				//올바른 비밀번호인지 확인이 되면 수정한다
				return dao.update(conn, vo);
			}
		} catch (NamingException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(conn);
		}
		return 0;
	}

}
