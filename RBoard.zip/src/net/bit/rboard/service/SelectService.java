package net.bit.rboard.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;

import javax.naming.NamingException;

import net.bit.rboard.dao.DaoProvider;
import net.bit.rboard.dao.RBoardCommentDao;
import net.bit.rboard.dao.RBoardDao;
import net.bit.rboard.db.DBCPProvider;
import net.bit.rboard.db.DBUtil;
import net.bit.rboard.vo.RBoardCommentVO;
import net.bit.rboard.vo.RBoardVO;

public class SelectService {
	private static SelectService instance = new SelectService();
	private SelectService() {}
	public static SelectService getInstance() {return instance;}
	
	public List<RBoardVO> select(int pageNo){
		Connection conn = null;
		System.out.println("SelectService의 select()실행");
		
		try {
			conn = DBCPProvider.getConnection();
			RBoardDao dao = DaoProvider.getInstance().getDao();
			
			//요청 페이지 목록을 얻어오기 위해 필요한 startNo와 endNo를 구하기 위한 계산
			int currentPage = pageNo;
			int totalCount = SelectCountService.getInstance().selectCount();
			int pageSize = 10;
			int totalPage = (totalCount - 1) / pageSize + 1;
			if(currentPage > totalPage) currentPage = totalPage;
			int startNo = (currentPage - 1) * pageSize + 1;
			int endNo = startNo + pageSize - 1;
			if(endNo > totalCount) endNo = totalCount;
			
			List<RBoardVO> list = dao.select(conn, startNo, endNo);
			return list;
			
		} catch (NamingException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(conn);
		}
		return null;	
	}
	
	public List<RBoardCommentVO> selectComment(int ref){
		Connection conn = null;
		try {
			conn = DBCPProvider.getConnection();
			RBoardCommentDao dao = DaoProvider.getInstance().getCommentDao();
			List<RBoardCommentVO> list = dao.select(conn, ref);
			return list;
		} catch (NamingException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(conn);
		}
		return Collections.emptyList();
	}

}
