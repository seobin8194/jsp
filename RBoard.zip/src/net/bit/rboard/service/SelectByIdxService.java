package net.bit.rboard.service;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;

import net.bit.rboard.dao.DaoProvider;
import net.bit.rboard.dao.RBoardDao;
import net.bit.rboard.db.DBCPProvider;
import net.bit.rboard.db.DBUtil;
import net.bit.rboard.vo.RBoardVO;

public class SelectByIdxService {
	private static SelectByIdxService instance = new SelectByIdxService();
	private SelectByIdxService() {}
	public static SelectByIdxService getInstance() {return instance;}
	
	public RBoardVO selectByIdx(int idx) {
		System.out.print("selectByIdxServie 실행");
		Connection conn = null;
		
		try {
			conn = DBCPProvider.getConnection();
			RBoardDao dao = DaoProvider.getInstance().getDao();
			
			//조회수를 증가하는 메소드 호출 후 해당 글을 가져온다
			dao.increment(conn, idx);
			return dao.selectByIdx(conn, idx);	
		} catch (NamingException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(conn);
		}
		return null;
	}

}
