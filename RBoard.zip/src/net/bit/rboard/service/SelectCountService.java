package net.bit.rboard.service;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;

import net.bit.rboard.dao.DaoProvider;
import net.bit.rboard.dao.RBoardCommentDao;
import net.bit.rboard.dao.RBoardDao;
import net.bit.rboard.db.DBCPProvider;
import net.bit.rboard.db.DBUtil;

public class SelectCountService {
	private static SelectCountService instance = new SelectCountService();
	private SelectCountService() {}
	public static SelectCountService getInstance() {return instance;}
	
	public int selectCount() {
		Connection conn = null;
		try {
			conn = DBCPProvider.getConnection();
			RBoardDao dao = DaoProvider.getInstance().getDao();
			return dao.selectCount(conn);		
		} catch (NamingException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(conn);
		}
		return 0;
	}
	
	public int selectCommentCount(int ref) {
		Connection conn = null;
		
		try {
			conn = DBCPProvider.getConnection();
			RBoardCommentDao dao = DaoProvider.getInstance().getCommentDao();
			return dao.selectCount(conn, ref);
		} catch (NamingException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(conn);
		}
		return 0;
	}
	
	
}
