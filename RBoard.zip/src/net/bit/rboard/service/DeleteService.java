package net.bit.rboard.service;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;

import net.bit.rboard.dao.DaoProvider;
import net.bit.rboard.dao.RBoardDao;
import net.bit.rboard.db.DBCPProvider;
import net.bit.rboard.db.DBUtil;
import net.bit.rboard.vo.RBoardVO;

public class DeleteService {
	private static DeleteService instance = new DeleteService();
	private DeleteService() {}
	public static DeleteService getInstance() {return instance;}
	
	public int delete(RBoardVO vo) {
		Connection conn = null;
		try {
			conn = DBCPProvider.getConnection();
			RBoardDao dao = DaoProvider.getInstance().getDao();
			RBoardVO originVo = dao.selectByIdx(conn, vo.getIdx());
			//올바른 비빌번호를 입력했을때 삭제처리를 한다
			if(originVo.getPassword().equals(vo.getPassword())) {
				return dao.delete(conn, vo.getIdx());
			}
		} catch (NamingException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(conn);
		}
		return 0;		
	}

}
