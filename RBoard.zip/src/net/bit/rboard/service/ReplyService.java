package net.bit.rboard.service;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;

import net.bit.rboard.dao.DaoProvider;
import net.bit.rboard.dao.RBoardDao;
import net.bit.rboard.db.DBCPProvider;
import net.bit.rboard.db.DBUtil;
import net.bit.rboard.vo.RBoardVO;

public class ReplyService {
	private static ReplyService instance = new ReplyService();
	private ReplyService() {}
	public static ReplyService getInstance() {return instance;}
	
	public int reply(RBoardVO vo) {
		Connection conn = null;
		
		try {
			conn = DBCPProvider.getConnection();
			RBoardDao dao = DaoProvider.getInstance().getDao();
			//AutoCommit 취소
			//트랜잭션이란 db에서 한번에 실행되어야할 명령의 집합
			//트랜잭션은 부분 완료를 시키면 안된다
			//tomcatDBCP를 사용할 경우 별도의 설정이 없으면 sql문 한개가 실행되면 자동으로 commit된다
			//따라서 2개이상의 sql문을 실행해여한다면 AutoCommit을 취소하고 모든 작업이 완료되면 conn.commit()을 실행
			conn.setAutoCommit(false);
			//lev과 seq를 1증가시킨다
			vo.setLev(vo.getLev() + 1);
			vo.setSeq(vo.getSeq() + 1);
			//seq 조절을 한다
			dao.incrementSeq(conn, vo.getRef(), vo.getSeq());
			//답글을 단다
			int res = dao.reply(conn, vo);
			conn.commit();
			return res;	
		} catch (Exception e) {
			DBUtil.rollback(conn);
		} finally {
			DBUtil.close(conn);
		}
		return 0;
	}
}
