package net.bit.rboard.db;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBCPProvider {
	public static Connection getConnection() throws NamingException, SQLException {
		//현재 웹 어플리케이션의 컨텍스트를 가져온다
		Context initContext = new InitialContext();
		//context.xml에서 지정한 리소스를 요청하면 dataSource 반환
		Context envContext = (Context) initContext.lookup("java:/comp/env");
		DataSource dataSource = (DataSource) envContext.lookup("jdbc/Oracle");
		//dataSource가 connection 요청을 수행한다
		Connection conn = dataSource.getConnection();
		return conn;
	}
	
	public static Connection getConnection(String db) throws NamingException, SQLException {
		Context initContext = new InitialContext();
		Context envContext = (Context) initContext.lookup("java:/comp/env");
		DataSource dataSource = (DataSource) envContext.lookup("jdbc/" + db);
		Connection conn = dataSource.getConnection();
		return conn;
	}

}
