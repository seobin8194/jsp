package net.bit.rboard.vo;

import java.util.ArrayList;
import java.util.List;

public class RBoardCommentList {
	private List<RBoardCommentVO> list = new ArrayList<RBoardCommentVO>();

	public List<RBoardCommentVO> getList() {
		return list;
	}

	public void setList(List<RBoardCommentVO> list) {
		this.list = list;
	}
}
