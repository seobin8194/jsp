package com.koreait.register;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RegisterDAO {
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	
	public RegisterDAO() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			conn = DriverManager.getConnection(url, "koreait", "0000");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//가입하려는 아이디가 테이블에 존재하는지 판단하는 메소드
	public int registerCheck(String userID) {
		try {
			String sql = "select * from register where userID = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userID);
			rs = pstmt.executeQuery();
			if(userID.trim().equals("")) {
				//아이디를 입력하지 않고 중복체크 버튼을 클릭했다면 2를 리턴
				return 2;
			}else if(rs.next()) {
				//select sql 명령 실행결과가 존재하면 이미 존재하는 회원이므로 0을 리턴
				return 0;
			}else {
				//select sql 명령 실행결과가 존재하지 않으면 존재하지 않은 회원이므로 1을 리턴
				return 1;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return -1;
	}
	
	//회원정보를 테이블에 저장하는 메소드
	public int register(RegisterVO vo) {
		try {
			String sql = "insert into register(userID, userPassword, userName, userAge, userGender, userEmail) values(?,?,?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getUserID());
			pstmt.setString(2, vo.getUserPassword());
			pstmt.setString(3, vo.getUserName());
			pstmt.setInt(4, vo.getUserAge());
			pstmt.setString(5, vo.getUserGender());
			pstmt.setString(6, vo.getUserEmail());
			//sql 명령이 정상적으로 처리되면 1을 리턴한다
			return pstmt.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		//오류가 발생하면 -1을 리턴한다
		return -1;
	}
}
